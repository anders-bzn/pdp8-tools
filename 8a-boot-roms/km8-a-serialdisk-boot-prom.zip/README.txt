==================================================================================

                                    README.txt

          Created by Anders Sandahl in 2018, for completely free use.

==================================================================================
This package contains two ROM images for the boot PROM's on the KM8-A in a PDP8a 
computer. They contain autostart and bootstrap for os8diskserver by Kyle Owen. 
The serial board in the PDP8a computer used for serialdisk must be on device 
address 40/41 to work. The images should be programmed onto empty PROM's, 74S387 
or N82S126N.

This archive should contain:

README.txt  		This file
rom1.bin  		ROM image for ROM-1
rom2.bin		ROM image for ROM-2
serialdisk.bin.txt	Human readable dump of the ROM's

Settings of the switches for KM8-A board. The computer will boot when the "Boot" 
button is activated. Start address in ROM: 20 octal

SW1       SW2
=======   =======
1 - ON    1 - ON
2 - ON    2 - OFF
3 - ON    3 - OFF
4 - OFF   4 - OFF
5 - OFF   5 - ON
6 - OFF   6 - ON
7 - OFF   7 - ON
8 - ON    8 - OFF

Futher details on setting the switches can be found in KM8-A engineering drawings, see 
http://www.bitsavers.org/pdf/dec/pdp8/pdp8a/KM8-A_Internal_Option_%232_Engineering_Drawings_1974.pdf)

More on os8diskserver, see https://github.com/drovak/os8diskserver

